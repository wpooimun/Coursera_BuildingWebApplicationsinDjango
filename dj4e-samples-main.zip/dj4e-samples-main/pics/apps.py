from django.apps import AppConfig


class PicsConfig(AppConfig):
    name = 'pics'
