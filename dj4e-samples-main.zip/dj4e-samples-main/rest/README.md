

https://www.django-rest-framework.org/tutorial/quickstart/

